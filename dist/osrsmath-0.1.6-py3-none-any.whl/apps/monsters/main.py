from osrsmath.apps.monsters.gui_single import Ui_MainWindow

if __name__ == "__main__":
	from osrsmath.apps.GUI.shared.application import run
	run(Ui_MainWindow)

import os

images_directory = os.path.join(os.path.dirname(__file__), 'images')